package com.ngovihung.android.cloudstorage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.exception.DropboxException;

public class UploadFile extends AsyncTask<Void, Long, Boolean> {

	private DropboxAPI<?> dropboxApi;
	private String path;
	private Context context;
	private String uploadFilePath;

	public UploadFile(Context context, DropboxAPI<?> dropboxApi,
			String path,String uploadFilePath) {
		this.context = context.getApplicationContext();
		this.dropboxApi = dropboxApi;
		this.path = path;
		this.uploadFilePath = uploadFilePath;
	}

	@Override
	protected Boolean doInBackground(Void... params) {
		final File tempDropboxDirectory = context.getCacheDir();
		File tempFileToUploadToDropbox;
		FileWriter fileWriter = null;
		String filename;
		
		try {
			System.out.println("Harvey -uploadFilePath="+uploadFilePath);
			tempFileToUploadToDropbox = new File(uploadFilePath);
			filename = tempFileToUploadToDropbox.getName();
			FileInputStream fis = new FileInputStream(tempFileToUploadToDropbox);
			System.out.println("Harvey - upload 1 filename="+filename);
			dropboxApi.putFileOverwrite(path +filename, fis, tempFileToUploadToDropbox.length(), null);
			System.out.println("Harvey - upload 2");
			/*
			// Creating a temporal file.
			tempFileToUploadToDropbox = File.createTempFile("file", ".txt", tempDropboxDirectory);
			fileWriter = new FileWriter(tempFileToUploadToDropbox);
			fileWriter.write("Hello World drom Android Dropbox Implementation Example!");
			fileWriter.close();

			// Uploading the newly created file to Dropbox.
			FileInputStream fileInputStream = new FileInputStream(tempFileToUploadToDropbox);
			dropboxApi.putFile(path + "hello_world.txt", fileInputStream,
					tempFileToUploadToDropbox.length(), null, null);
			tempFileToUploadToDropbox.delete();
			*/
			return true;
		} catch (IOException e) {
			System.out.println("Harvey -  upload 3:"+e.toString());
			e.printStackTrace();
		} catch (DropboxException e) {
			System.out.println("Harvey - upload 3:"+e.toString());
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	protected void onPostExecute(Boolean result) {
		if (result) {
			Toast.makeText(context, "File has been successfully uploaded!",
					Toast.LENGTH_LONG).show();
		} else {
			Toast.makeText(context, "An error occured while processing the upload request.",
					Toast.LENGTH_LONG).show();
		}
	}
}