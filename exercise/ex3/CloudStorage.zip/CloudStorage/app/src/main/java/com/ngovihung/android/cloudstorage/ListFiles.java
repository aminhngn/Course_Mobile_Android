package com.ngovihung.android.cloudstorage;

import java.util.ArrayList;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.DropboxAPI.Entry;
import com.dropbox.client2.exception.DropboxException;

public class ListFiles extends AsyncTask<Void, Void, ArrayList<String>> {

	private DropboxAPI<?> dropboxApi;
	private String path;
	private Handler handler;

	public ListFiles(DropboxAPI<?> dropboxApi, String path, Handler handler) {
		this.dropboxApi = dropboxApi;
		this.path = path;
		this.handler = handler;
	}

	@Override
	protected ArrayList<String> doInBackground(Void... params) {
		System.out.println("Harvey - 1");
		ArrayList<String> files = new ArrayList<String>();
		try {
			System.out.println("Harvey - listFile 2");
			Entry directory = dropboxApi.metadata(path, 1000, null, true, null);
			System.out.println("Harvey - listFile 3");
			for (Entry entry : directory.contents) {
				System.out.println("Harvey - listFile file:"+entry.fileName());
				files.add(entry.fileName());
			}
		} catch (DropboxException e) {
			System.out.println("Harvey - listFile error");
			e.printStackTrace();
		}
		return files;
	}

	@Override
	protected void onPostExecute(ArrayList<String> result) {
		Message message = handler.obtainMessage();
		Bundle bundle = new Bundle();
		bundle.putStringArrayList("data", result);
		message.setData(bundle);
		handler.sendMessage(message);
	}
}