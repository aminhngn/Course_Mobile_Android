package com.example.ngovihung.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends ActionBarActivity {

    private ImageView searchBtn, messageBtn;
    private LinearLayout.LayoutParams dashBoardViewParams;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //View aaa = this.findViewById(R.id.aaa);
    }

    @Override
    protected void onStart() {
        super.onStart();

        //LayoutInflater mInflaterTopGame = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //View a1 = mInflaterTopGame.inflate(R.layout.message);

        messageBtn =  (ImageView)this.findViewById(R.id.messageBtn);
        messageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("hung - search - onClick");
                setContentView(R.layout.message);
            }
        });
        searchBtn =  (ImageView)this.findViewById(R.id.searchBtn);
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("hung - search - onClick");
                setContentView(R.layout.screen_search);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
