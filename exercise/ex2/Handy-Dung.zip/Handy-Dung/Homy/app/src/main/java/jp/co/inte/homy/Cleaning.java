package jp.co.inte.homy;

/**
 * Created by dam.duy.dung on 5/20/2015.
 */
public class Cleaning {
    public void Cleaning() {

    }

}
